import os
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


@pytest.fixture()
def client(monkeypatch):
    tmp = tempfile.mkdtemp()
    monkeypatch.setenv("DB_PATH", os.path.join(tmp, "test.db"))
    monkeypatch.delenv("ADMIN_API_KEY", raising=False)
    import importlib
    import database, main
    importlib.reload(database)
    importlib.reload(main)
    with TestClient(main.app) as c:
        yield c


def reg(client, i, **extra):
    return client.post("/register", json={"name": f"Student {i}", "email": f"s{i}@x.com", **extra})


def test_successful_registration(client):
    r = reg(client, 1, college="VIT", department="CSE")
    assert r.status_code == 201
    body = r.json()
    assert body["id"] == 1 and body["college"] == "VIT" and body["registered_at"]


def test_college_optional(client):
    assert reg(client, 1).status_code == 201


def test_duplicate_email_case_insensitive(client):
    assert reg(client, 1).status_code == 201
    r = client.post("/register", json={"name": "Again", "email": "S1@X.COM"})
    assert r.status_code == 409 and r.json()["error"] == "duplicate_registration"


@pytest.mark.parametrize("payload", [
    {}, {"name": "A"}, {"email": "a@b.com"},
    {"name": "  ", "email": "a@b.com"},
    {"name": "A", "email": "not-an-email"},
])
def test_invalid_input(client, payload):
    r = client.post("/register", json=payload)
    assert r.status_code == 422 and r.json()["error"] == "invalid_input"


def test_capacity_limit(client):
    for i in range(50):
        assert reg(client, i).status_code == 201
    r = reg(client, 999)
    assert r.status_code == 409 and r.json() == {"error": "event_full", "message": "Event is full"}
    assert len(client.get("/registrations").json()) == 50
    assert client.get("/").json()["seats_left"] == 0


def test_capacity_holds_under_concurrency(client):
    with ThreadPoolExecutor(max_workers=16) as ex:
        results = list(ex.map(lambda i: reg(client, i).status_code, range(80)))
    assert results.count(201) == 50
    assert results.count(409) == 30


def test_list_and_get(client):
    reg(client, 1); reg(client, 2)
    assert len(client.get("/registrations").json()) == 2
    assert client.get("/registrations/2").json()["email"] == "s2@x.com"
    assert client.get("/registrations/email/S1@x.com").json()["id"] == 1


def test_not_found(client):
    assert client.get("/registrations/42").status_code == 404
    assert client.get("/registrations/42").json()["error"] == "not_found"
    assert client.get("/registrations/email/no@x.com").status_code == 404


def test_admin_key(client, monkeypatch):
    monkeypatch.setenv("ADMIN_API_KEY", "secret")
    reg(client, 1)
    assert client.get("/registrations").status_code == 401
    assert client.get("/registrations", headers={"X-API-Key": "secret"}).status_code == 200
    assert reg(client, 2).status_code == 201  # students don't need the key
